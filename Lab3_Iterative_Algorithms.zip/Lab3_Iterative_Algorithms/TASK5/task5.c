#include <stdio.h>

int main() {
    int N;
    printf("Please enter the number of characters: ");
    scanf("%d", &N);

    char ch;
    int a_count = 0, e_count = 0, i_count = 0, o_count = 0, u_count = 0;
    int others_count = 0;

    printf("Please enter %d characters:\n", N);
    for (int j = 0; j < N; j++) {
        scanf(" %c", &ch);


        switch (ch) {


                case 'a':
                case 'A':
                        a_count = a_count + 1;
                        break;

                case 'e':
                case 'E':
                        e_count = e_count + 1;
                        break;

                case 'i':
                case 'I':
                        i_count = i_count + 1;
                        break;

                case 'o':
                case 'O':
                        o_count = o_count + 1;
                        break;

                case 'u':
                case 'U':
                        u_count = u_count + 1;
                        break;

                default:
			others_count = others_count + 1;
			break;
	}
    }


    printf("Frequency of a = %d\n", a_count);
    printf("Frequency of e = %d\n", e_count);
    printf("Frequency of i = %d\n", i_count);
    printf("Frequency of o = %d\n", o_count);
    printf("Frequency of u = %d\n", u_count);
    printf("Frequency of others = %d\n", others_count);

    return 0;
}
