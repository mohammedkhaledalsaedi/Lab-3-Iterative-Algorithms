#include <stdio.h>

int main() {
    int city = 0;
    printf("Enter the number of cities: \n");
    scanf("%d", &city);

    int population;
    int sum = 0;
    int max;
    int min;

    for (int i = 1; i <= city; i++) {  


        printf("Enter the population of city %d: ", i);
        scanf("%d", &population);
        
        sum = sum + population;

        if (i == 1) {
            max = min = population;

        } 
	
	else {

            if (population > max) {
                max = population;
            }

            if (population < min) {
                min = population;
            }
        }
    }

    float average = (float)sum / city;

    printf("Average population: %.2f\n", average);
    printf("Maximum population: %d\n", max);
    printf("Minimum population: %d\n", min);

    return 0;
}

