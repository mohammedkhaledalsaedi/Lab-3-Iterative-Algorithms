


#include <stdio.h>

int main() {

//a	
	int N = 0;
	int i = 0;


	printf("Enter a positive integer N: \n");
	scanf("%d", &N);
	printf("\nNumbers from %d to 0 in descending order: \n", N);


	for (i=N; i>=0;i-- ) {

		printf("%d ", i);
	}


	printf("\n");

	
//b
	

	for (int j=1; j<=N; j++) {

		
		if (j%10 == 4) {
			continue;
			
		}
		if (j%10 ==7) {
			continue;
		}
		printf("%d ", j);


		

	}

//c	
	float F;
	printf("\nEnter an increment value less than 1: \n");
	scanf("%f", &F);


	if (F >= 0 && F < 1) {

		for (float k=0; k<=N; k=k+F) {

			printf("%.1f ", k);
		}
	}
	else {

		printf("error: Wrong value, please enter a valid value\n");
	}




	printf("\n");

	return 0;

}
