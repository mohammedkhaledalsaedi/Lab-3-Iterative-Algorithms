#include <stdio.h>
#include <stdbool.h>


int main() {
    int N;
    bool isPrime = true;

    printf("Enter a number: ");
    scanf("%d", &N);

    if (N <= 1) {
        isPrime = false;
    }



    
    else {
        for (int i = 2; i < N; i++) {
            if (N % i == 0) {
                isPrime = false;
                break;
            }
        }





    }


    if (isPrime) {
        printf("This is a prime number.\n");
    }


    else {
        printf("This is not a prime number.\n");

    }


    return 0;
}

